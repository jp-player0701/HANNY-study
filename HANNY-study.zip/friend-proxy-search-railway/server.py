# friend proxy 用の検索サーバー (Railway 用)
#
# やること: パスコードが合ってる人だけに、ddgs (DuckDuckGo) の検索結果を返す。
# 呼び方  : POST { "q": "ことば", "role": "member" か "admin", "code": "パスコード" }
# 返す形  : { "results": [ { "title", "url", "snippet" }, ... ] }
#
# 環境変数 (Railway の Variables。なくても動く)
#   ALLOW_ORIGIN : サイトのURL (例 https://example.pages.dev)。入れると、そのサイトからだけ呼べる
#   PORT         : Railway が自動で入れる。自分で決めなくていい

import hashlib
import hmac
import json
import os
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# friend-proxy.html と同じ。パスコードそのものではなく sha256("fp:<role>:<code>")
HASHES = {
    "member": "1402c10022436c3819150966f364a88e3df3bd03b8be608f32e5d50960b11462",
    "admin": "252beb99c029fece9ad24082a74501d9e78adedfab11ea3f11594bf2ad8312c7",
}
MAX_BODY = 4096
MAX_RESULTS = 15


def authed(role, code):
    if role not in HASHES or not isinstance(code, str) or len(code) > 40:
        return False
    h = hashlib.sha256(("fp:%s:%s" % (role, code)).encode("utf-8")).hexdigest()
    return hmac.compare_digest(h, HASHES[role])


def search(q):
    from ddgs import DDGS

    rows = DDGS().text(q, region="jp-jp", safesearch="moderate", max_results=MAX_RESULTS)
    out = []
    for r in rows or []:
        url = r.get("href") or r.get("url") or ""
        if not url.startswith(("http://", "https://")):
            continue
        out.append({
            "title": str(r.get("title") or "")[:120],
            "url": url,
            "snippet": str(r.get("body") or "")[:300],
        })
    return out


class Handler(BaseHTTPRequestHandler):
    def _send(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Access-Control-Allow-Origin", os.environ.get("ALLOW_ORIGIN") or "*")
        self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Vary", "Origin")
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        self._send(200, {"ok": True})   # 動いてるかの確認用

    def do_OPTIONS(self):
        self._send(204, {})

    def do_POST(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
        except ValueError:
            n = 0
        if n <= 0 or n > MAX_BODY:
            return self._send(400, {"error": "bad request"})
        try:
            b = json.loads(self.rfile.read(n).decode("utf-8"))
        except Exception:
            return self._send(400, {"error": "bad json"})
        if not isinstance(b, dict):
            return self._send(400, {"error": "bad json"})

        if not authed(b.get("role"), b.get("code")):
            return self._send(401, {"error": "auth"})

        q = b.get("q")
        q = q.strip()[:200] if isinstance(q, str) else ""
        if not q:
            return self._send(200, {"results": []})
        try:
            return self._send(200, {"results": search(q)})
        except Exception:
            return self._send(502, {"error": "upstream"})

    def log_message(self, *args):
        pass  # 検索ことばをログに残さない


if __name__ == "__main__":
    port = int(os.environ.get("PORT") or 8080)
    ThreadingHTTPServer(("0.0.0.0", port), Handler).serve_forever()
