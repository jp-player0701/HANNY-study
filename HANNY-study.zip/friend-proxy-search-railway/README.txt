friend proxy 検索サーバー (ddgs) の置き方 (Railway)

1. GitHub にリポジトリを作って、この friend-proxy-search-railway フォルダの中身
   (server.py / requirements.txt / Procfile) を入れる。
2. https://railway.com にログインして、New Project → Deploy from GitHub repo で、そのリポジトリを選ぶ。
3. デプロイが終わったら、そのサービスの Settings → Networking で、
   「Generate Domain」(公開用のURLを作る) を押す。
4. できたURL (例: https://名前.up.railway.app) を、index.html の SEARCH_URL に入れる。
   (最後に / を付けても付けなくてもいい)
5. 動いてるかの確認: そのURLをブラウザで開いて、{"ok": true} と出ればOK。
6. 任意: Railway の Variables に ALLOW_ORIGIN を作って、サイトのURL
   (例: https://名前.pages.dev) を入れる。入れると、そのサイトからだけ呼べるようになる。

※ 画面の名前は、少し違うことがあるよ。
